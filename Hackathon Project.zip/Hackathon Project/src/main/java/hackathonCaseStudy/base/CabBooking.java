package hackathonCaseStudy.base;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import hackathonCaseStudy.utility.ExcelUtils;

import hackathonCaseStudy.utility.DriverSetup;

public class CabBooking extends DriverSetup {
	
	String file = System.getProperty("user.dir") + "\\TestData\\HackathonInputData.xlsx";
	
	By website = By.xpath("//a[@href='https://www.makemytrip.com/cabs/']");
	By labelForCity = By.xpath("//label[@for='fromCity']");
	By labelToCity = By.xpath("//label[@for='toCity']");
	By searchFrom = By.xpath("//input[@placeholder='From']");
	By searchTo = By.xpath("//input[@placeholder='To']");
	By suggestion = By.xpath("(//p[@class='searchedResult font14 darkText'])[1]");
	By departure = By.xpath("//div[@aria-label='Mon Jul 24 2023']");
	By pickupTimeHr = By.xpath("(//li[@class='hrSlotItemParent'])[7]");
	By pickupTimeMin = By.xpath("(//li[@class='minSlotItemParent'])[6]");
	By pickupTimeApply = By.xpath("//span[@class='applyBtnText']");
	By searchButton = By.xpath("//a[normalize-space()='Search']");
	By checkSuv = By.xpath("//label[normalize-space()='SUV']");
	By appliedFilter = By.xpath("//div[@class='appliedFilterButton']");
	By lowestPrice = By.xpath("//p[@class='font28 latoBlack blackText ']");
	
	public void launchCabPage() {
		
		driver.findElement(website).click();
	}
	 
	public void fillCabData() throws InterruptedException, IOException {
		driver.findElement(labelForCity).click();
		
		String from = ExcelUtils.getCellData(file, "sheet1", 1, 1);
		driver.findElement(searchFrom).sendKeys(from);
		Thread.sleep(3000);
		driver.findElement(suggestion).click();
		
		driver.switchTo().activeElement();
		
		String to = ExcelUtils.getCellData(file, "sheet1", 1, 2);
		driver.findElement(searchTo).sendKeys(to);
		Thread.sleep(3000);
		driver.findElement(suggestion).click();
		
		driver.switchTo().activeElement();
		
		driver.findElement(departure).click();
		
		driver.switchTo().activeElement();
		
		driver.findElement(pickupTimeHr).click();
		driver.findElement(pickupTimeMin).click();
		driver.findElement(pickupTimeApply).click();
		driver.findElement(searchButton).click();
	}

	
	public WebElement getSuv() {
		return driver.findElement(checkSuv);
	}
	
	public WebElement getAppliedFilter() {
		return driver.findElement(appliedFilter);
	}
	
	public List<WebElement> getLowestPrice() {
		return driver.findElements(lowestPrice);
	}
}
