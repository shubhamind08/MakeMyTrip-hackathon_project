package hackathonCaseStudy.base;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import hackathonCaseStudy.utility.DriverSetup;

public class HotelFunctionality extends DriverSetup {

	By website = By.xpath("(//a[@href='https://www.makemytrip.com/hotels/'])[1]");
	By guestBox = By.xpath("//label[@for='guest']");
	By adultsField = By.xpath("(//div[@class='gstSlctCont'])[2]");
	By adults = By.xpath("//div[@class='makeFlex primaryTraveler']//li");
	
	public void launchHotelWebsite() {
		driver.findElement(website).click();
	}
	
	public WebElement getGuestBox() {
		return driver.findElement(guestBox);
	}
	
	public WebElement getAdultsField() {
		return driver.findElement(adultsField);
	}
	
	public void extractAdults() {
		getGuestBox().click();
		getAdultsField().click();
		List<WebElement> adl = driver.findElements(adults);
		for(WebElement e : adl) {
			System.out.print("You can select " + e.getText() + " Adults ");
			System.out.println("OR");
		}
	}
}
