package hackathonCaseStudy.base;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;

import hackathonCaseStudy.utility.DriverSetup;
import hackathonCaseStudy.utility.ExcelUtils;

public class GiftCard extends DriverSetup{

	String file = System.getProperty("user.dir") + "\\TestData\\HackathonInputData.xlsx";
	
	By giftCardIcon = By.xpath("//li[@data-cy='tertiaryRowItem_Gift Cards']");
	By allRadioButton = By.xpath("//p[normalize-space()='All']");
	By clearCategory = By.xpath("//a[normalize-space()='Clear']");
	By weddingGiftCard = By.xpath("//img[@alt='banner']");
	By headingWGC = By.xpath("//h1[normalize-space()='Wedding Gift Card']");
	By senderName = By.xpath("//input[@name='senderName']");
	By senderMobile = By.xpath("//input[@name='senderMobileNo']");
	By senderMail = By.xpath("//input[@name='senderEmailId']");
	By errorMessage = By.xpath("//p[@class='red-text font11 append-top5']");
	By buyNow = By.xpath("//button[normalize-space()='BUY NOW']");
	By errorArea = By.xpath("//div[@id='deliveredSection']");
	
	
	
	public void launchGiftCard() {
		driver.findElement(giftCardIcon).click();
		Set<String> windows = driver.getWindowHandles();
		List<String> ids = new ArrayList<String>(windows);
		
		String giftCardPage = ids.get(1);
		
		driver.switchTo().window(giftCardPage);
	}
	
	public WebElement getAllRadioButton() {
		return driver.findElement(allRadioButton);
	}
	
	public void clearAllCategories() {
		driver.findElement(clearCategory).click();
	}
	
	public void selectGiftCard() {
		driver.findElement(weddingGiftCard).click();
	}
	
	public String getHeadingOfGiftCrad() {
		return driver.findElement(headingWGC).getText();
	}
	
	public void setSenderData() throws IOException {
		String name = ExcelUtils.getCellData(file, "sheet1", 1, 3);
		driver.findElement(senderName).sendKeys(name);
		String number = ExcelUtils.getCellData(file, "sheet1", 1, 4);
		driver.findElement(senderMobile).sendKeys(number);
		String mail = ExcelUtils.getCellData(file, "sheet1", 1, 5);
		driver.findElement(senderMail).sendKeys(mail);
		
	}
	
	public void clickBuyNow() {
		driver.findElement(buyNow).click();
	}
	
	public String getInvalidErrorMessage() {
		return driver.findElement(errorMessage).getText();
	}
	
	public void captuteError() throws IOException {
		WebElement error = driver.findElement(errorArea);
		File srcLoc = error.getScreenshotAs(OutputType.FILE);
		File destLoc = new File(System.getProperty("user.dir") + "//Screenshots//GiftCardError//invalidEmail.png");
		FileUtils.copyFile(srcLoc, destLoc);
	}
}
