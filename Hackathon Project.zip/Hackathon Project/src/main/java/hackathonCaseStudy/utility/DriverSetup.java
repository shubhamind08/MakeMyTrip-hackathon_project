package hackathonCaseStudy.utility;

import java.io.IOException; 
import java.time.Duration;
import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverSetup {
	
	public static WebDriver driver;
	String file = System.getProperty("user.dir") + "\\TestData\\HackathonInputData.xlsx";
	
	public static WebDriver getWebDriver(String browser) {
		if (browser.equals("1")) {
			driver = getChromeDriver();
		}
		else if(browser.equals("2")) {
			driver = getEdgeDriver();
		}
		else {
			System.out.println("Enter either 1 or 2");
		}
		return driver;
	}

	private static WebDriver getEdgeDriver() {
		// TODO Auto-generated method stub
		WebDriverManager.edgedriver().setup();

		driver = new EdgeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		return driver;
	}

	private static WebDriver getChromeDriver() {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();

		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		return driver;
	}
	
	public void getUrl() throws IOException {
		String url = ExcelUtils.getCellData(file, "sheet1", 1, 0);
		driver.get(url);
	}
	
	@BeforeSuite(groups= {"Smoke", "Regression"})
	public void setUpBrowser(){
		Scanner sc = new Scanner(System.in);
		System.out.println(":------------: Hackathon Case Study :------------:");
		System.out.println("Enter the browser name:\n1. Chrome\n2.Edge");
		String webBrowser = sc.nextLine();
		try {
		getWebDriver(webBrowser);
		}
		catch(Exception e) {
			System.out.println("Bad Entry");
		}
		sc.close();
	}
	

	@AfterSuite(groups= {"Smoke", "Regression"})
	public void tearDown() {
		driver.quit();
	}

}
