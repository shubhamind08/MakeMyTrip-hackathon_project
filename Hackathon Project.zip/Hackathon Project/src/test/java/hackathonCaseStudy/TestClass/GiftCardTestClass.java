package hackathonCaseStudy.TestClass;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import hackathonCaseStudy.base.GiftCard;
import hackathonCaseStudy.utility.DriverSetup;

public class GiftCardTestClass extends DriverSetup{
	
	public GiftCard gc = new GiftCard();
	
	@Test(priority=6, groups= {"Smoke", "Regression"})
	public void Test_GiftCardPage() throws InterruptedException, IOException {
		getUrl();
		Thread.sleep(6000);
		gc.launchGiftCard();
		String expected = "Gift Cards - Buy Gift Card Online, Gift Vouchers | MakeMyTrip.com";
		String actual = driver.getTitle();
		Assert.assertEquals(actual, expected);
	}

	@Test(priority=7, groups= {"Regression"})
	public void Test_RemoveCategory() {
		gc.clearAllCategories();
		WebElement radioButton = gc.getAllRadioButton();
		Assert.assertFalse(radioButton.isSelected());
	}
	
	@Test(priority=8, groups= {"Regression"})
	public void Test_HeadingOfWeddingGiftCard() throws InterruptedException {
		Thread.sleep(1500);
		gc.selectGiftCard();
		String expected = "Wedding Gift Card";
		String actual = gc.getHeadingOfGiftCrad();
		Assert.assertEquals(expected, actual);
	}
	
	@Test(priority=9, groups= {"Regression"})
	public void Test_InvalidEmail() throws IOException, InterruptedException {
		gc.setSenderData();
		gc.clickBuyNow();
		String error = gc.getInvalidErrorMessage();
		Thread.sleep(3000);
		gc.captuteError();
		Assert.assertTrue(false, error);
	}
}
