package hackathonCaseStudy.TestClass;


import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import hackathonCaseStudy.base.CabBooking;
import hackathonCaseStudy.utility.DriverSetup;

public class CabPageTestClass extends DriverSetup {

	public CabBooking cb = new CabBooking();
	
	@Test(priority=1, groups= {"Smoke", "Regression"})
	public void TestCabPageTitle() throws InterruptedException, IOException {
		getUrl();
		Thread.sleep(10000);
		cb.launchCabPage();
		String expected = "Online Cab Booking - Book Outstation Cabs at Lowest Fare @ MakeMyTrip";
		String actual = driver.getTitle();
		Assert.assertEquals(expected, actual);
	}

	@Test(priority=2, groups= {"Regression"})
	public void TestCabDataFilling() throws InterruptedException, IOException {
		cb.fillCabData();
		String expected = "Cabs";
		String actual = driver.getTitle();
		Assert.assertEquals(expected, actual);
	}
	
	@Test(priority=3, groups= {"Regression"})
	public void TestDisplaySUV() throws InterruptedException {
		cb.getSuv().click();
		Thread.sleep(3000);
		String dummy = cb.getAppliedFilter().getText();
		Assert.assertEquals("SUV", dummy);
		String pr = cb.getLowestPrice().get(0).getText();
		System.out.println("Lowesr fare is: " + pr);
		Thread.sleep(3000);
	}
	
}
