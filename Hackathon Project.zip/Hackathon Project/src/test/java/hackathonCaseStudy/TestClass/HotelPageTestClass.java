package hackathonCaseStudy.TestClass;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import hackathonCaseStudy.base.HotelFunctionality;
import hackathonCaseStudy.utility.DriverSetup;

public class HotelPageTestClass extends DriverSetup{

	HotelFunctionality hf = new HotelFunctionality();
	
	@Test(priority=4, groups= {"Smoke", "Regression"})
	public void TestHotelPageTitle() throws InterruptedException, IOException {
		getUrl();
		Thread.sleep(10000);
		hf.launchHotelWebsite();
		String expected = "MakeMyTrip.com: Save upto 60% on Hotel Booking 4,442,00+ Hotels Worldwide";
		String actual = driver.getTitle();
		Assert.assertEquals(expected, actual);
	}
	
	@Test(priority=5, groups= {"Regression"})
	public void TestAdultsCount() {
		boolean a = hf.getGuestBox().isDisplayed();
		hf.extractAdults();
		Assert.assertTrue(a);
	}
}
